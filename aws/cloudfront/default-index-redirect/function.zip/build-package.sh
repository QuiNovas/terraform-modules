#!/usr/bin/env bash

# npm install async
zip -r function.zip *
