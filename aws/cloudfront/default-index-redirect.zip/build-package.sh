#!/usr/bin/env bash

npm install async
zip -r ../default-index-redirect.zip *
